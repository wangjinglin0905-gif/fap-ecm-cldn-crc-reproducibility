CAF supplementary source data. Source DOI: 10.1038/s41586-026-10344-7.
Definitions are source-detectability-adapted continuous programs, not validated subtype classifiers.
All primary, negative, sensitivity and auxiliary results are retained.
Source scripts and raw input download manifests are maintained separately and require public-release synchronization before submission.
