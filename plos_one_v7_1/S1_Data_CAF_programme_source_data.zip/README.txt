CAF supplementary source data. Source DOI: 10.1038/s41586-026-10344-7.
Definitions are source-detectability-adapted continuous programs, not validated subtype classifiers.
All primary, negative, sensitivity and auxiliary results are retained.
Portable analysis scripts and public input-download manifests are provided in the caf_extension module of GitHub release v2.1.1 (https://github.com/wangjinglin0905-gif/fap-ecm-cldn-crc-reproducibility/releases/tag/v2.1.1).
